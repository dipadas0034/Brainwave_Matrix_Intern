const ctx = document.getElementById('transaction-chart').getContext('2d');
let transactionChart;
let transactions = JSON.parse(localStorage.getItem('transactions')) || [];
const totalAmountElement = document.getElementById('total-amount');

// Categories and Icons
const categories = {
  food: { icon: 'coffee', color: '#ff7675' },
  transport: { icon: 'navigation', color: '#74b9ff' },
  shopping: { icon: 'shopping-bag', color: '#a29bfe' },
  bills: { icon: 'file-text', color: '#55efc4' },
  entertainment: { icon: 'film', color: '#ffeaa7' },
  income: { icon: 'dollar-sign', color: '#00b894' },
};

// DOM Elements
const addTransactionBtn = document.getElementById('add-transaction-btn');
const filterButtons = document.querySelectorAll('.filter-btn');

// Initialize
updateTotal();
renderTransactions();
initChart();

// Event Listeners
addTransactionBtn.addEventListener('click', addTransaction);
filterButtons.forEach(btn => btn.addEventListener('click', () => {
  filterButtons.forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  updateChart(btn.dataset.range);
}));

function addTransaction() {
  const name = document.getElementById('transaction-name').value.trim();
  const amount = parseFloat(document.getElementById('transaction-amount').value);
  const type = document.getElementById('transaction-type').value;
  const date = new Date().toISOString().split('T')[0]; // Automatically fetch current date

  if (name && amount) {
    const category = getCategory(name);
    const transaction = { name, amount, type, date, category };
    transactions.push(transaction);
    localStorage.setItem('transactions', JSON.stringify(transactions));
    renderTransactions();
    updateTotal();
    updateChart(document.querySelector('.filter-btn.active').dataset.range);
    clearInputs();
  } else {
    alert('Please fill all fields!');
  }
}

function renderTransactions() {
  const list = document.getElementById('transaction-list');
  list.innerHTML = '';
  
  transactions.forEach((transaction, index) => {
    const li = document.createElement('li');
    li.innerHTML = `
      <span>
        <i data-feather="${categories[transaction.category].icon}"></i>
        <strong>${transaction.name}</strong>
        <small>${new Date(transaction.date).toLocaleDateString()}</small>
      </span>
      <span style="color: ${transaction.type === 'expense' ? '#ff7675' : '#00b894'}">
        ${transaction.type === 'expense' ? '-' : '+'}$${transaction.amount.toFixed(2)}
        <button onclick="deleteTransaction(${index})">×</button>
      </span>
    `;
    list.appendChild(li);
  });
  feather.replace(); // Refresh icons
}

function deleteTransaction(index) {
  transactions.splice(index, 1);
  localStorage.setItem('transactions', JSON.stringify(transactions));
  renderTransactions();
  updateTotal();
  updateChart(document.querySelector('.filter-btn.active').dataset.range);
}

function updateTotal() {
  const total = transactions.reduce((sum, t) => t.type === 'income' ? sum + t.amount : sum - t.amount, 0);
  totalAmountElement.textContent = `$${total.toFixed(2)}`;
}

function initChart() {
  transactionChart = new Chart(ctx, {
    type: 'line',
    data: { datasets: [{
      label: 'Transactions',
      borderColor: '#6c5ce7',
      tension: 0.4,
      fill: true,
      backgroundColor: (context) => {
        const ctx = context.chart.ctx;
        const gradient = ctx.createLinearGradient(0, 0, 0, 400);
        gradient.addColorStop(0, 'rgba(108, 92, 231, 0.2)');
        gradient.addColorStop(1, 'rgba(108, 92, 231, 0.01)');
        return gradient;
      }
    }]},
    options: {
      responsive: true,
      plugins: { legend: { display: false } },
      scales: { y: { beginAtZero: true } }
    }
  });
}

function updateChart(range) {
  const filtered = filterTransactions(range);
  const labels = [...new Set(filtered.map(t => t.date))].sort();
  const data = labels.map(date => 
    filtered.filter(t => t.date === date).reduce((sum, t) => t.type === 'income' ? sum + t.amount : sum - t.amount, 0)
  );

  transactionChart.data.labels = labels;
  transactionChart.data.datasets[0].data = data;
  transactionChart.update();
}

function filterTransactions(range) {
  const now = new Date();
  return transactions.filter(t => {
    const date = new Date(t.date);
    switch(range) {
      case 'daily': return date.toDateString() === now.toDateString();
      case 'weekly': return getWeekNumber(date) === getWeekNumber(now);
      case 'monthly': return date.getMonth() === now.getMonth();
    }
  });
}

function getWeekNumber(d) {
  d = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()));
  d.setUTCDate(d.getUTCDate() + 4 - (d.getUTCDay() || 7));
  const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
  return Math.ceil(((d - yearStart) / 86400000 + 1) / 7);
}

function getCategory(name) {
  const lowerName = name.toLowerCase();
  if (lowerName.includes('food') || lowerName.includes('restaurant')) return 'food';
  if (lowerName.includes('transport') || lowerName.includes('bus')) return 'transport';
  if (lowerName.includes('shopping') || lowerName.includes('store')) return 'shopping';
  if (lowerName.includes('bill') || lowerName.includes('rent')) return 'bills';
  if (lowerName.includes('movie') || lowerName.includes('entertain')) return 'entertainment';
  return 'income';
}

function clearInputs() {
  document.getElementById('transaction-name').value = '';
  document.getElementById('transaction-amount').value = '';
}